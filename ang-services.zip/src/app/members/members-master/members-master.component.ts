import { Component, OnInit } from '@angular/core';
import { MembersService } from '../services/members.service';

@Component({
  selector: 'asrv-members-master',
  templateUrl: './members-master.component.html',
  styleUrls: ['./members-master.component.css']
})
export class MembersMasterComponent implements OnInit {

  constructor(public membersService: MembersService) { }

  ngOnInit() { }

}
