import { Injectable } from '@angular/core';
import { Member } from '../classes/member';

@Injectable()
export class MembersService {
  /**
   * DECLARACIÓN DE LAS VARIABLES QUE SE EMPLEARÁN EN EL MÓDULO
   */

  public User: Member; // Almacenará los datos de un nuevo usuario en un objeto de la clase adecuada
  public UsersArray: Member[] = []; // Almacenará los objetos de clase Member en una matriz
  public NumberOfMembers = 0; // Contendrá el número de miembros cuando se añadan o eliminen
  public indexToEdit: number; // Contendrá el índice de un elemento de la matriz que vayamos a editar.

  public typeOfAction = 'C'; // (C)rear o (E)ditar

  public dni: string; // Para el ngModel con el formulario
  public nombre: string; // Para el ngModel con el formulario

  public errorDetected = false; // Para el mensaje cuando haya un error al grabar los datos de un miembro
  public recordOK = false; // Para el mensaje cuando se graben correctamente los datos de un miembro

  constructor() {
    // Se inicializan en blanco las variables del ngModel del formulario
    this.dni = '';
    this.nombre = '';
  }

  /**
   * El siguiente método comprueba los datos tecleados en el formulario cuando se intenta grabar.
   * La comprobación de DNI repetido difiere si es una creación de registro, o una edición.
   * También difiere el método al que se invoca a continuación, si los datos son correctos.
   */
  checkRecord() {
    if (this.dni === '' || this.nombre === '') {
      this.errorDetected = true;
    }
    for (const item of this.UsersArray) {
      if (this.typeOfAction === 'C' && item.dni === this.dni) {
        this.errorDetected = true;
      }
      if (
        this.typeOfAction === 'E' &&
        item.dni === this.dni &&
        this.UsersArray.indexOf(item) !== this.indexToEdit
      ) {
        this.errorDetected = true;
      }
    }
    this.recordOK = !this.errorDetected;
    if (this.recordOK === true) {
      if (this.typeOfAction === 'C') {
        this.saveRecord();
      } else {
        this.confirmEdition();
      }
    }
  }

  /**
   * Si los datos son correctos, en la operación de registro nuevo,
   * se crea el correspondiente objeto Member y se añade a la matriz,
   * actualizando el número de registros.
   */
  saveRecord() {
    // Creamos un objeto de la clase AcdUser
    this.User = new Member(this.dni, this.nombre);
    this.dni = '';
    this.nombre = '';
    // Añadimos el objeto a la matriz de miembros
    this.UsersArray.push(this.User);
    this.NumberOfMembers = this.UsersArray.length;
  }

  /**
   * Cuando se enfoca un campo del formulario se borra la última notificación
   */
  clearNotice() {
    this.errorDetected = false;
    this.recordOK = false;
  }

  /**
   * Cuando se pide eliminar un registro.
   * @param User
   */
  deleteUser(User) {
    const index = this.UsersArray.indexOf(User);
    this.UsersArray.splice(index, 1);
    this.NumberOfMembers = this.UsersArray.length;
  }

  /**
   * Cuando se pide editar un registro, se anota el índice que ocupa en la matriz,
   * y se cargan sus datos en las variables que enlazan por ngModel con el formulario.
   * Así, se colocan los datos en los correspondientes campos, para poder editarlos.
   * @param User
   */
  editUser(User) {
    this.indexToEdit = this.UsersArray.indexOf(User);
    this.typeOfAction = 'E';
    this.dni = User.dni;
    this.nombre = User.nombre;
  }

  /**
   * Cuando se confirma la edición de un registro, se cambian sus datos.
   * Después se invoca al método cancelEdition(), que lo único que
   * hace es dejar el formulario preparado para crear un nuevo registro.
   */
  confirmEdition() {
    this.UsersArray[this.indexToEdit].dni = this.dni;
    this.UsersArray[this.indexToEdit].nombre = this.nombre;
    this.cancelEdition();
  }

  cancelEdition() {
    this.typeOfAction = 'C';
    this.dni = '';
    this.nombre = '';
  }
}
